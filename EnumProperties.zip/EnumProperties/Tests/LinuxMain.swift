import XCTest

import EnumPropertiesTests

var tests = [XCTestCaseEntry]()
tests += EnumPropertiesTests.allTests()
XCTMain(tests)
