# EnumProperties

A description of this package.
