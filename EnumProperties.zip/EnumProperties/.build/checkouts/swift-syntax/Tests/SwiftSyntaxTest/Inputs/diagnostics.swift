func foo() {

}

func bar() {

}

func baz() {

}