// A closure without a signature. The test will ensure it stays the same after
// applying a rewriting pass.
let x: () -> Void = {}