struct Foo {
  func foo() {
    print("hello")
    func bar() {
      print("goodbye")
    }
  }
}
