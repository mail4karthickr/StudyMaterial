func foo() {
  public func foo() {
    func foo() {
      /*Unknown token */0xG
    }
  }
}
