import XCTest
@testable import SnapshotTestingTests

XCTMain([
  testCase(SnapshotTestingTests.allTests),
])
