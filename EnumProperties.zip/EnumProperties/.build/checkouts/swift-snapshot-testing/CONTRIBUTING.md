# Contributing

## Code of Conduct

This project and everyone participating in it is governed by its [Code of Conduct](CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code. Please report unacceptable behavior to support@pointfree.co.
