import XCTest

@available(swift, obsoleted: 5.0, renamed: "XCTestCase", message: "Please use XCTestCase instead")
public typealias SnapshotTestCase = XCTestCase
