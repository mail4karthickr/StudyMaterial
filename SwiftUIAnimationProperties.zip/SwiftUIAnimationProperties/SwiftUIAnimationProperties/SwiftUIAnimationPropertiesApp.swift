//
//  SwiftUIAnimationPropertiesApp.swift
//  SwiftUIAnimationProperties
//
//  Created by Karthick Ramasamy on 14/03/22.
//

import SwiftUI

@main
struct SwiftUIAnimationPropertiesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
